#!/bin/bash
java -jar peers.jar
